public class Printer {
//    public void print(Governo governo) {
//        printTotal(governo.acoes);
//        printPrioritarios(governo.searchAcoesByPrioridade(true));
//        printTrimestre(governo.searchAcoesTrimestre());
//    }
    public void print(Acao[] array) {
        for(Acao acao: array){
            System.out.println(acao);
        }
    }
    public void printQuantidade(int quantidade) {
        System.out.println("Esta eh a quantidade de acoes executadas em 2017: " + quantidade);
    }


}
