
public class Main {
    public static void main(String[] args) {
        View view = new View();
        Printer printer = new Printer();
        Governo gov = new Governo();
        int qtdTotal = view.lerQuantidadeAcoes();
        gov.acoes = new Acao[qtdTotal];
        gov = view.lerGoverno(gov);
        gov.acoes = view.lerAcoes(gov.acoes);
        Acao[] acoes = gov.acoes;
        Acao[] acoesPrioridade = gov.searchAcoesByPrioridade(true);
        Acao[] acoesTrimestre = gov.searchAcoesTrimestre();
        int qtd = gov.countAcoesAno(2017);
        printer.print(acoes);
        printer.print(acoesPrioridade);
        printer.print(acoesTrimestre);
        printer.printQuantidade(qtd);
    }
}
