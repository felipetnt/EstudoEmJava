public class Governo {
    Acao[] acoes;
    public int countAcoesAno(int ano){
        int qtd = 0;
        for(Acao acao : acoes){
            if(acao.ano == ano){
                qtd++;
            }
        }
        return qtd;
    }
    public int countAcoesByPrioridade(boolean prioridade){
        int qtd = 0;
        for(Acao acao : acoes){
            if(acao.isPrioridade() == prioridade){
                qtd++;
            }
        }
        return qtd;
    }
    public Acao[] searchAcoesByPrioridade(boolean prioridade) {
        Governo gov = new Governo();
        Acao[] acoesPrioridade = new Acao[countAcoesByPrioridade(prioridade, gov)];
        int i = 0;
        for (Acao acao : gov.acoes) {
            if (acao.isPrioridade() == prioridade) {
                acoesPrioridade[i++] = acao;
            }
        }
        return acoesPrioridade;
    }
    public int countAcoesTrimestre (String trimestre){
        Governo gov = new Governo();
        int qtd = 0;
        for(Acao acao : gov.acoes){
            if(acao.getTrimestre().equals(trimestre)){
                qtd++;
            }
        }
        return qtd;
    }
    public Acao[] searchAcoesTrimestre() {
        Governo gov = new Governo();
        Acao[] acoesTrimestre = new Acao[countAcoesTrimestre("Terceiro")];
        int i = 0;
        for (Acao acao : gov.acoes) {
            if (acao.getTrimestre().equals("Terceiro")) {
                acoesTrimestre[i++] = acao;
            }
        }
        return acoesTrimestre;
    }
}
