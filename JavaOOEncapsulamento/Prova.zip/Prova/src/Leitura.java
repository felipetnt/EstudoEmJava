import java.util.Scanner;
public class Leitura {
    public String lerString(String texto){
        return new Scanner(System.in).nextLine();
    }
}
