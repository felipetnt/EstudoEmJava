public class Pasta {
    int ano;
    Documento[] documentos = new Documento[0];

    public void adicionar(Documento documento) {
        Documento[] aux = new Documento[documentos.length + 1];
        int i = 0;
        for( i = 0; i < documentos.length; i++){
            aux[i] = documentos[i];
        }
        aux[i] = documento;
        documentos = aux;
    }

    public int totalBytesDoc() {
        int total = 0;
        for(Documento documento : documentos){
            total += documento.bytes;
        }
        return total;
    }

    public int countExtensao(String extensao){
        int total = 0;
        for(Documento documento: documentos){
            if(documento.extencao.equals(extensao)){
                total++;
            }
        }
        return total;
    }

    public Documento[] toExtensao(String extensao) {
        Documento[] toExtensao = new Documento[countExtensao(extensao)];
        int i = 0;
        for(Documento documento : documentos){
            if(documento.extencao.equals(extensao)){
                toExtensao[i] = documento;
            }
        }
        return toExtensao;
    }

    @Override
    public String toString() {
        String s = "Ano da pasta: " + ano + "\n";
        for(Documento documento : documentos){
            s += documento.toString();
        }
        return s;
    }
    public String toString2() {
        String s = "Ano da pasta: " + ano + "\n";
        for(Documento documento : documentos){
            s += documento.nome;
        }
        return s;
    }
}
