public class ServicePasta {
    Pasta[] pastas = new Pasta[0];

    public void adicionar(Pasta pasta) {
        Pasta[] aux = new Pasta[pastas.length + 1];
        int i = 0;
        for(i = 0; i < pastas.length; i++){
            aux[i] = pastas[i];
        }
        aux[i] = pasta;
        pastas = aux;
    }

    public String toString(){
        String s = "";
        for(Pasta pasta : pastas){
            s += pasta.toString() + pasta.ano;
        }
        return s;
    }

    public String toString2(){
        String s = "";
        for(Pasta pasta : pastas){
            s += pasta.toString2();
        }
        return s;
    }
    public void getPastasExtensao(String extencao) {
        for(Pasta pasta : pastas){
            for(Documento documento : pasta.documentos){
                if(documento.extencao.equals(extencao)){
                    System.out.println(documento);
                }
            }
        }
    }

    public void getPastasAno(int ano) {
        for(Pasta pasta : pastas){
            if(pasta.ano == ano){
                System.out.println(pasta);
            }
        }
    }

    public int totalBytes(){
        int total = 0;
        for(Pasta pasta : pastas){
            total += pasta.totalBytesDoc();
        }
        return total;
    }

}
