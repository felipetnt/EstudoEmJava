public class Laboratorio {
    String local;
    Item[] itens;
    ResponsavelT responsavelT;

    public int countLaboratorioItensType(Boolean itemType){
        int qtd = 0;
        for(Item item : itens){
            if(item.isType("TECNOLOGICO") == itemType){
                qtd++;
            }
        }
        return qtd;
    }

    public double custoLaboratorioItens(){
        double precoLab = 0;
        for(Item item : itens){
            precoLab += item.preco;
        }
        return precoLab;
    }

}
